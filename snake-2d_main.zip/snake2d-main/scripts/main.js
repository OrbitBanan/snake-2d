let scoreBlock;
let score = 0;

const config = {
	step: 0,
	maxStep: 6,
	sizeCell: 16,
	sizeBerry: 16 / 4
}

const snake = {
	x: 160,
	y: 160,
	dx: config.sizeCell,
	dy: 0,
	tails: [],
	maxTails: 3
}

let berry = {
	x: 0,
	y: 0
}

let canvas = document.querySelector("#game-canvas");
let context = canvas.getContext("2d");
scoreBlock = document.querySelector(".game-score .score-count");
drawScore();

function gameLoop() {

	requestAnimationFrame( gameLoop );
	if ( ++config.step < config.maxStep) {
		return;
	}
	config.step = 0;

	context.clearRect(0, 0, canvas.width, canvas.height);

	drawBerry();
	drawSnake();
}
requestAnimationFrame( gameLoop );

let snakeColor = "#A00034";
let secondSnakeColor = "#FA0556";
let berryColor = "#A00034";

const purpleBtn = document.getElementById('Purple');
function purpleColor() {
	scoreBlock.style.color = '#b621fe';
	snakeColor = '#800080';
	secondSnakeColor = '#b621fe';
	berryColor = '#800080';
}
purpleBtn.addEventListener('click', purpleColor)


const greenBtn = document.getElementById('Green');
function greenColor() {
	scoreBlock.style.color = '#3CB371';
	snakeColor = '#006400';
	secondSnakeColor = '#3CB371';
	berryColor = '#006400';
}
greenBtn.addEventListener('click', greenColor)


const YellowBtn = document.getElementById('Yellow');
function YellowColor() {
	scoreBlock.style.color = '#FFFF00';
	snakeColor = '#DAA520';
	secondSnakeColor = '#FFFF00';
	berryColor = '#DAA520';
}
YellowBtn.addEventListener('click', YellowColor)


const redBtn = document.getElementById('Red');
function redColor() {
	scoreBlock.style.color = '#FA0556';
	snakeColor = '#A00034';
	secondSnakeColor = '#FA0556';
	berryColor = '#A00034';
}
redBtn.addEventListener('click', redColor)


const LightBlueBtn = document.getElementById('LightBlue');
function lightBlueColor() {
	scoreBlock.style.color = '#00BFFF';
	snakeColor = '#40E0D0';
	secondSnakeColor = '#00BFFF';
	berryColor = '#40E0D0';
}
LightBlueBtn.addEventListener('click', lightBlueColor)


const blueBtn = document.getElementById('Blue');
function BlueColor() {
	scoreBlock.style.color = '#0000FF';
	snakeColor = '#00008B';
	secondSnakeColor = '#0000FF';
	berryColor = '#00008B';
}
blueBtn.addEventListener('click', BlueColor);

const orangeBtn = document.getElementById('Orange');
function orangeColor() {
	scoreBlock.style.color = '#FFA500';
	snakeColor = '#D2691E';
	secondSnakeColor = '#FFA500';
	berryColor = '#D2691E';
}
orangeBtn.addEventListener('click', orangeColor);

const whiteBtn = document.getElementById('White');
function whiteColor() {
	scoreBlock.style.color = '#FFFFFF';
	snakeColor = '#A9A9A9';
	secondSnakeColor = '#FFFFFF';
	berryColor = '#FFFFFF';
}
whiteBtn.addEventListener('click', whiteColor)

function drawSnake() {
	snake.x += snake.dx;
	snake.y += snake.dy;

	collisionBorder();

	snake.tails.unshift({x: snake.x, y: snake.y});

	if (snake.tails.length > snake.maxTails) {
		snake.tails.pop();
	}

	snake.tails.forEach(function (el, index) {
		if (index == 0) {
			context.fillStyle = secondSnakeColor;
		} else {
			context.fillStyle = snakeColor;
		}

		context.fillRect(el.x, el.y, config.sizeCell, config.sizeCell);

		if (el.x === berry.x && el.y === berry.y) {
			snake.maxTails++;
			incScore();
			randomPositionBerry();
		}

		for (let i = index + 1; i < snake.tails.length; i++) {

			if (el.x == snake.tails[i].x && el.y == snake.tails[i].y) {
				gameOver();
			}

		}

	});
}

function collisionBorder() {
	if (snake.x < 0) {
		snake.x = canvas.width - config.sizeCell;
	} else if ( snake.x >= canvas.width ) {
		snake.x = 0;
	}

	if (snake.y < 0) {
		snake.y = canvas.height - config.sizeCell;
	} else if ( snake.y >= canvas.height ) {
		snake.y = 0;
	}
}

function gameOverMenu() {
	custom_alert();
}

function gameOver() {
	//alert('Ты проиграл! Твой счёт: ' + score);
	gameOverMenu();
	refreshGame();
}

function refreshGame() {
	score = 0;
	drawScore();

	snake.x = 160;
	snake.y = 160;
	snake.tails = [];
	snake.maxTails = 3;
	snake.dx = config.sizeCell;
	snake.dy = 0;

	randomPositionBerry();
}
function drawBerry() {
	context.beginPath();
	context.fillStyle = berryColor;
	context.arc( berry.x + (config.sizeCell / 2 ), berry.y + (config.sizeCell / 2 ), config.sizeBerry, 0, 2 * Math.PI );
	context.fill();
}

function randomPositionBerry() {
	berry.x = getRandomInt( 0, canvas.width / config.sizeCell ) * config.sizeCell;
	berry.y = getRandomInt( 0, canvas.height / config.sizeCell ) * config.sizeCell;
}

function incScore() {
	score++;
	drawScore();
}

function drawScore() {
	scoreBlock.innerHTML = score;
}

function getRandomInt(min, max) {
	return Math.floor( Math.random() * (max - min) + min );
}

document.addEventListener("keydown", function (e) {
	if ( e.code == "KeyW" ) {
		snake.dy = -config.sizeCell;
		snake.dx = 0;
	} else if ( e.code == "KeyA" ) {
		snake.dx = -config.sizeCell;
		snake.dy = 0;
	} else if ( e.code == "KeyS" ) {
		snake.dy = config.sizeCell;
		snake.dx = 0;
	} else if ( e.code == "KeyD" ) {
		snake.dx = config.sizeCell;
		snake.dy = 0;
	}
});
if (document.getElementById) {
	window.alert = function (alert_message) {
		custom_alert(alert_message);
	}
}

function custom_alert(alert_message) {
	const ALERT_TITLE = "Ты проиграл! Твой счёт: " + score;
	const ALERT_BUTTON_TEXT = "Заново";
	let is_alert_container_exist = document.getElementById("alert_container");
	if (is_alert_container_exist) {
		return;
	}
	let get_body_element = document.querySelector("body");
	let div_for_alert_container = document.createElement("div");
	let alert_container = get_body_element.appendChild(div_for_alert_container);

	alert_container.id = "alert_container";
	alert_container.className = "alert_container"

	let div_for_alert_box = document.createElement("div")
	let alert_box = alert_container.appendChild(div_for_alert_box);
	alert_box.className = "alert_box";

	alert_box.style.top = document.documentElement.scrollTop + "px";
	alert_box.style.left = (document.documentElement.scrollWidth - alert_box.offsetWidth) / 2 + "px";

	let alert_header_tag = document.createElement("h1");
	let alert_title_text = document.createTextNode(ALERT_TITLE)
	let alert_title= alert_box.appendChild(alert_header_tag);
	alert_title.appendChild(alert_title_text);

	let alert_paragraph_tag = document.createElement("p");
	let alert_message_container = alert_box.appendChild(alert_paragraph_tag);
	alert_message_container.textContent = alert_message;

	let ok_button_tag = document.createElement("button");
	let ok_button_text = document.createTextNode(ALERT_BUTTON_TEXT)
	let ok_button = alert_box.appendChild(ok_button_tag);
	ok_button.className = "close_btn";
	ok_button.appendChild(ok_button_text);

	ok_button.addEventListener("click", function () {
		remove_custom_alert();
	}, false);
}

function remove_custom_alert() {
	let HTML_body = document.querySelector("body");
	let alert_container = document.getElementById("alert_container");
	HTML_body.removeChild(alert_container);
}